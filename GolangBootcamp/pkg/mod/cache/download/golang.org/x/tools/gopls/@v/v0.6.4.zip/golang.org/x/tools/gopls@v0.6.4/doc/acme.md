# Acme

Use the experimental [`acme-lsp`] plugin.
Get started by following the[installation guide].

[`acme-lsp`]: https://github.com/fhs/acme-lsp
[installation guide]: https://github.com/fhs/acme-lsp#gopls
